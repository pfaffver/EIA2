/* Endaufgabe
Name: Verena Pfaff
Matrikel: 256543
Datum: 13.02.2018 */
var final;
(function (final) {
    class bildFehler extends final.bild {
        constructor(_x, _y, _color) {
            super(_x, _y, _color);
        }
    }
    final.bildFehler = bildFehler;
})(final || (final = {}));
//# sourceMappingURL=bildFehler.js.map